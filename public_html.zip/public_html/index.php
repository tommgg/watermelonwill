<!DOCTYPE html>
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="jspdf.min.js"></script>
<meta name="viewport" content="width=device-width">
<meta name="viewport" content="initial-scale=1.0">
<title>Watermelon Will</title>
</head>
<body>
<div id="titlebar">
  <h2>Watermelon Will</h2>
  <ul id="sitemenu">
    <li><a href="home">HOME</a></li>
    <li><a href="/wills" id="selectedmenuitem">CREATE</a></li>
    <li><a href="blog">BLOG</a></li>
    <li><a href="faqs">FAQs</a></li>
    <li><a href="contact">CONTACT</a></li>
  </ul>
</div>
<div id="maincontentcontainer">
	<div id="questionmenu">
	  <ul>
	    <li id="selectedstep"><a href="#" data-section="personalinfo" data-sectiontitle="Personal">Personal</a></li>
	    <li><a href="#" data-section="specificgifts" data-sectiontitle="Specific Gifts">Specific Gifts</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Pets">Pets</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Final Wishes">Final Wishes</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Intentional Exclusion">Intentional Exclusion</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Residuary Estate">Residuary Estate(needed??)</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Life Insurance">Life Insurance</a></li>
	    <li><a href="#" data-section="executorinfo" data-sectiontitle="Executor">Executor</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Witnesses">Witnesses</a></li>
	    <li><a href="#" data-section="checkout" data-sectiontitle="Check Out">Check Out</a></li>
	    <li><a href="#" data-section="allothers" data-sectiontitle="Post-creation">Post-creation</a></li>
	  </ul>
	</div>
	<div id="maincontent">
	<div id="sectiontitle"><h3>Personal</h3><hr></div>
	  <form id="questions">
	  <!-- personal info -->
	  <fieldset data-section="personalinfo" class="currentinsection" data-enabled="true">
	    <h1>What is your legal name?</h1>
	    <input type="text" id="name" class="propername"/>
	    <div class="help-tip"><p>Please enter your full legal name as it appears on your birth certificate and other legal documents. Exmaples: John Michael Doe, Louis Frederick Smith Jr., and Sarah Marie Roe II. Having trouble with this question? Email us <a href="mailto:thomas.watermelonwill@gmail.com?subject=Question%20about%20inputting%20name">here</a>.</p></div>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="true">
	    <h1>In which state do you live?</h1>
	    <select id="state" name="state"><option selected disabled>Select State...</option></select>
	    <div class="help-tip"><p>lmao dropdown</p></div>
	  </fieldset>
	  <!--<fieldset data-section="personalinfo" data-enabled="true">
	    <h1>In which county do you live?</h1>
	    <select id="county" name="county"><option selected disabled>Select County...</option></select>
	    <div class="help-tip"><p>lmao dropdown 2</p></div>
	  </fieldset>-->
	  <fieldset data-section="personalinfo" data-enabled="true">
	    <h1>Are you married?</h1>
	    <button id="married" type=button>YES</button>
	    <button id="notmarried" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" id="identifyspouse" data-enabled="false">
	    <h1>Who is your spouse?</h1>
	    <input type="text" id="spousename" class="propername" />
	    <div class="help-tip"><p>Please enter your spouse's full legal name as it appears on his/her birth certificate and other legal documents. Exmaples: John Michael Doe, Louis Frederick Smith Jr., and Sarah Marie Roe II. Having trouble with this question? Email us <a href="mailto:thomas.watermelonwill@gmail.com?subject=Question%20about%20inputting%20spouse%20name">here</a>.</p></div>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="false" id="childrenfromcurrentmarriage">
	    <h1>Do you have any children from your current marriage?</h1>
	    <button id="haschildrenfromcurrentmarriage" type=button>YES</button>
	    <button id="nochildrenfromcurrentmarriage" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="false" id="identifychildrenfromcurrent">
	    <h1>Identify the children from your current marriage.</h1>
	    <input type="text" id="childname" class="propername" /><button type=button id="insideinput">Add Child ↩</button>
	    <div class="help-tip"><p>Please identify your children by typing their name and hitting enter. The table below displays all children you have already identified. Typically, first and last name is sufficient here. Example: John Appleseed. Having trouble with this question? Email us <a href="mailto:thomas.watermelonwill@gmail.com?subject=Question%20about%20inputting%current%20children">here</a>.</p></div>
	    <div class="tablecontainer"><table id="childrenfromcurrenttable" class="newtable">
	    <thead>
	    <tr><th>Children from Current Marriage</th></tr>
	    </thead>
	    <tbody>
	    <tr><td>No children entered yet.</td></tr>
	    </tbody>
	    </table></div>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="false" id="everbeenmarried">
	    <h1>Have you ever been married?</h1>
	    <button id="hasbeenmarried" type=button>YES</button>
	    <button id="neverbeenmarried" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="false" id="childrenfromprevious">
	    <h1>Do you have any children you have not listed yet?</h1>
	    <button id="haschildrenfromprevious" type=button>YES</button>
	    <button id="nochildrenfromprevious" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="false" id="identifychildrenfromprevious">
	    <h1>Identify all of your other children.</h1>
	    <input type="text" id="otherchildname" class="propername" /><button type=button id="otherinsideinput">Add Child ↩</button>
	    <div class="help-tip"><p>Please identify your children from other marriages than your current by typing their name and hitting enter. This includes adopted children. The table below displays all children you have already identified. Typically, first and last name is sufficient here. Example: John Appleseed. Having trouble with this question? Email us <a href="mailto:thomas.watermelonwill@gmail.com?subject=Question%20about%20inputting%current%20children">here</a>.</p></div>
	    <div class="tablecontainer"><table id="childrenfromprevioustable" class="newtable">
	    <thead>
	    <tr><th>Other Children</th></tr>
	    </thead>
	    <tbody>
	    <tr><td>No children entered yet.</td></tr>
	    </tbody>
	    </table></div>
	  </fieldset>
	  <!--<fieldset data-section="personalinfo" data-enabled="false" id="childrenunder18">
	    <h1>Are any of your children under 18?</h1>
	    <button id="haschildrenunder18" type=button>YES</button>
	    <button id="nochildrenunder18" type=button>NO</button>
	  </fieldset>-->
	  <fieldset data-section="personalinfo" data-enabled="true" id="legalguardian">
	    <h1>Are you legal guardian of anyone?</h1>
	    <button id="islegalguardian" type=button>YES</button>
	    <button id="notlegalguardian" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" data-enabled="true" id="legalguardian">
	    <h1>Are you legal guardian of anyone?</h1>
	    <button id="islegalguardian" type=button>YES</button>
	    <button id="notlegalguardian" type=button>NO</button>
	  </fieldset>
	  <fieldset data-section="personalinfo" id="identifylegalguardian" data-enabled="false">
	    <h1>Identify someone who should be the legal guardian of those who currently rely on you.</h1>
	    <input type="text" id="legalguardian" class="propername" />
	    <div class="help-tip"><p>Please enter the full legal name of the person who should be your replacement as legal guardian. Exmaples: John Michael Doe, Louis Frederick Smith Jr., and Sarah Marie Roe II. Having trouble with this question? Email us <a href="mailto:thomas.watermelonwill@gmail.com?subject=Question%20about%20inputting%20spouse%20name">here</a>.</p></div>
	  </fieldset>
	  
	  <!-- check out -->
	  <fieldset data-section="checkout" id="checkout" data-enabled="true" class="currentinsection">
	    <table id="purchaseoptions" callspacing="10"><tr><th>One-time download</th><th>Unlimited</th></tr><tr><td>$20</td><td>$15/year (minimum of 2 years)</td></tr></table>
	  </fieldset>
	  
	 </form>
	 
	  <div id="questionsnavigation">
	   <hr/>
	   <ul>
	   <li><a href="#" id="back">← BACK</a></li>
	   <li><a href="#" id="save">SAVE PROGRESS</a></li>
	   <li><a href="#" id="gen">GENERATE WILL</a></li>
	   <li><a href="#" id="next">NEXT →</a></li>
	   </ul>
	  </div>
	  
	  </div>
	  
</div>
	  
<script type = "text/javascript">

/* VARIABLES FOR WILL GENERATION */

var legalName = "";
var spouseLegalName = "";
var state = "";
var hasChildrenFromCurrentMarriage = false;
var hasChildrenFromPreviousMarriage = false;
var childrenUnder18 = false;
var currentMarriageChildren = [];
var previousMarriageChildren = [];
var isMarried = false;
//var childrenUnder18 = false;
var everBeenMarried = false;
var isLegalGuardian = false;

/* END VFWG */

$(document).ready(function() {

	checkOverlay();
	$(window).resize(function() {
		checkOverlay();
	});
	
	function checkOverlay() {
		var windowsize = (window.innerWidth > 0) ? window.innerWidth : screen.width;
		if (windowsize < 670) {
			if ($('#overlay').length == 0){
				$('html').append('<div id="overlay"><p>Please visit Watermelon Will creator on a larger device.</p></div>');
			}
		} else {
			$('#overlay').detach();
		}
	}

	$('#questions').find('fieldset').hide();
	
	$('#questions fieldset').each(function(){
    		if ($(this).data('section') == 'personalinfo' && $(this).attr('class') == 'currentinsection') {
    			$(this).css('display','block');
    		}
	});

	$('#questionmenu ul li').click(function() {
	
		//reset all
		$('#questionmenu ul li a').css('font-weight','400');
		$('#questionmenu ul li').removeAttr('id');
		
		//set current
		$(this).find('a').css('font-weight','600');
		$(this).find('a').css('text-decoration','none');
		$(this).attr('id','selectedstep');

		//get current questions
		selectedA = $(this).find('a');
		$('#questions').find('fieldset').hide();
		
		$('#sectiontitle h3').text(selectedA.data('sectiontitle'));
		
		$('#questions fieldset').each(function(){
	    		if ($(this).data('section') == selectedA.data('section') && $(this).attr('class') == 'currentinsection') {
	    			$(this).css('display','block');
	    		}
		});

	});
	
	$('#next').click(function() {
	
		document.activeElement.blur();
	
		$('#questions fieldset').each(function(){
	    		if ($(this).css('display') == 'block') {
	    			var section = $(this).data('section');
	    			
	    			var fieldsetsInSection = $('*[data-section="' + section + '"]').toArray();
	    			
	    			var pos = 0;
	    			var currentStep;
	    			
	    			$('#questions fieldset').each(function(){
			    		if ($(this).data('section') == section && $(this).attr('class') == 'currentinsection') {
			    			currentStep = $(this);
			    			pos = $.inArray($(this)[0], fieldsetsInSection);
			    		}
				});
				
				var count = pos;
				while (!$('#questions').find(fieldsetsInSection[count+1]).data('enabled') && count < fieldsetsInSection.length) {
				count++;
				}
				
				//console.log(count);
				//console.log($('#questions').find(fieldsetsInSection[pos+1]).data('enabled'));
	    			
	    			if (pos < fieldsetsInSection.length - 1 && $('#questions').find(fieldsetsInSection[count+1]).data('enabled')) {
	    			
	    				currentStep.removeAttr('class');
	    				$('#questions').find(fieldsetsInSection[count + 1]).attr('class','currentinsection');
	    				$('#questions fieldset').hide();
	    				$('.currentinsection*[data-section="' + section + '"]').css('display','block');
	    				
	    			}

	    			return false;
	    		}
	    		
		});
	
	});
	
	$('#back').click(function() {
	
		document.activeElement.blur();
	
		$('#questions fieldset').each(function(){
	    		if ($(this).css('display') == 'block') {
	    			var section = $(this).data('section');
	    			
	    			var fieldsetsInSection = $('*[data-section="' + section + '"]').toArray();
	    			
	    			var pos = 0;
	    			var currentStep;
	    			
	    			$('#questions fieldset').each(function(){
			    		if ($(this).data('section') == section && $(this).attr('class') == 'currentinsection') {
			    			currentStep = $(this);
			    			pos = $.inArray($(this)[0], fieldsetsInSection);
			    		}
				});
				
				var count = pos;
				while (!$('#questions').find(fieldsetsInSection[count-1]).data('enabled') && count > 1) {
				count--;
				}
				
	    			
	    			if (count > 1 && $('#questions').find(fieldsetsInSection[count-1]).data('enabled')) {
	    			
	    				currentStep.removeAttr('class');
	    				$('#questions').find(fieldsetsInSection[count - 1]).attr('class','currentinsection');
	    				$('#questions fieldset').hide();
	    				$('.currentinsection*[data-section="' + section + '"]').css('display','block');
	    				
	    			
	    			}

	    			return false;
	    		}
	    		
		});
	
	});
	
	$('#save').click(function() {
	
		document.activeElement.blur();
	
	});
	
	$('#gen').click(function() {
	
		document.activeElement.blur();
		generate();
	
	});
	
	$('#sitemenu li a').click(function() {
	
		document.activeElement.blur();
	
	});
	
	$('#insideinput').click(function() {
	
		addCurrentMarriageChildren();
	
	});
	
	$('#otherinsideinput').click(function() {
	
		addPreviousMarriageChildren();
	
	});
	
	$('#haschildrenfromcurrentmarriage').click(function() {
		$(this).css('background-color','#333');
		$('#nochildrenfromcurrentmarriage').css('background-color','#3cc47c');
		hasChildrenFromCurrentMarriage = true;
		updateForm();
	
	});
	
	$('#nochildrenfromcurrentmarriage').click(function() {
		$(this).css('background-color','#333');
		$('#haschildrenfromcurrentmarriage').css('background-color','#3cc47c');
		hasChildrenFromCurrentMarriage = false;
		updateForm();
	});
	
	$('#married').click(function() {
	
		$(this).css('background-color','#333');
		$('#notmarried').css('background-color','#3cc47c');
		isMarried = true;
		updateForm();
	});
	
	$('#notmarried').click(function() {
	
		$(this).css('background-color','#333');
		$('#married').css('background-color','#3cc47c');
		hasChildrenFromCurrentMarriage = false;
		isMarried = false;
		updateForm();
	
	});
	
	$('#hasbeenmarried').click(function() {
	
		$(this).css('background-color','#333');
		$('#neverbeenmarried').css('background-color','#3cc47c');
		everBeenMarried = true;
		updateForm();
	
	});
	
	$('#neverbeenmarried').click(function() {
	
		$(this).css('background-color','#333');
		$('#hasbeenmarried').css('background-color','#3cc47c');
		everBeenMarried = false;
		updateForm();
	
	});
	
	$('#spousename').on('keyup', function() {
	
		spouseLegalName = $(this).val();
	
	});
	
	$('#name').on('keyup', function() {
	
		legalName = $(this).val();
		
	});
	
	$('#haschildrenfromprevious').click(function() {
	
		$(this).css('background-color','#333');
		$('#nochildrenfromprevious').css('background-color','#3cc47c');
		hasChildrenFromPreviousMarriage = true;
		updateForm()
	
	});
	
	
	$('#nochildrenfromprevious').click(function() {
	
		$(this).css('background-color','#333');
		$('#haschildrenfromprevious').css('background-color','#3cc47c');
		hasChildrenFromPreviousMarriage = false;
		updateForm();
	
	});
	
	$('#haschildrenunder18').click(function() {
	
		$(this).css('background-color','#333');
		$('#nochildrenunder18').css('background-color','#3cc47c');
		childrenUnder18 = true;
		//updateForm();
	
	});
	
	$('#nochildrenunder18').click(function() {
	
		$(this).css('background-color','#333');
		$('#haschildrenunder18').css('background-color','#3cc47c');
		childrenUnder18 = false;
		//updateForm();
	
	});
	
	$('#islegalguardian').click(function() {
	
		$(this).css('background-color','#333');
		$('#notlegalguardian').css('background-color','#3cc47c');
		isLegalGuradian = true;
		updateForm();
	
	});
	
	$('#notlegalguardian').click(function() {
	
		$(this).css('background-color','#333');
		$('#islegalguardian').css('background-color','#3cc47c');
		isLegalGuradian = false;
		updateForm();
	
	});
	
	function updateForm() {
	
		if(isMarried) {
			$('#identifyspouse').data('enabled',true);
			$('#childrenfromcurrentmarriage').data('enabled',true);
			$('#everbeenmarried').data('enabled',false);
		} else {
			$('#identifyspouse').data('enabled',false);
			$('#childrenfromcurrentmarriage').data('enabled',false);
			$('#everbeenmarried').data('enabled',true);
		}
		
		if(hasChildrenFromCurrentMarriage) {
			$('#identifychildrenfromcurrent').data('enabled',true);
		} else {
			$('#identifychildrenfromcurrent').data('enabled',false);
		}
		
		//if(everBeenMarried || isMarried) {
			$('#childrenfromprevious').data('enabled',true);
		//} else {
		//	$('#childrenfromprevious').data('enabled',false);
		//}
		
		if(hasChildrenFromPreviousMarriage) {
			$('#identifychildrenfromprevious').data('enabled',true);
		} else {
			$('#identifychildrenfromprevious').data('enabled',false);
		}
		
		if(hasChildrenFromCurrentMarriage || hasChildrenFromPreviousMarriage) {
			$('#childrenunder18').data('enabled',true);
		} else {
			$('#childrenunder18').data('enabled',false);
		}
		
		if(isLegalGuardian) {
			$('#identifylegalguardian').data('enabled',true);
		} else {
			$('#identifylegalguardian').data('enabled',false);
		}
		
		
	}
	
	$('#childname').keyup(function(e){
		if(e.keyCode == 13) {
			
			addCurrentMarriageChildren();
			
		}
	    
	});
	
	$('#otherchildname').keyup(function(e){
		if(e.keyCode == 13) {
			
			addPreviousMarriageChildren();
			
		}
	    
	});
	
	function addCurrentMarriageChildren() {
	
		if($('#childname').val() != '') {
	
			currentMarriageChildren.push($('#childname').val().trim());
			//console.log(currentMarriageChildren);
				
			var htmlString = "";
			
			for (var i = 0; i < currentMarriageChildren.length; i++) {
				htmlString += "<tr><td>";
				htmlString += currentMarriageChildren[i];
				htmlString += '<span style="float:right;cursor:pointer" onclick="removeCurrentChild(' + i + ')">✕</span></td></tr>';
			}
			
			$('#childrenfromcurrenttable tbody').html(htmlString);
			
			$('#childname').val('');
			
		}
	
	}
	
	function addPreviousMarriageChildren() {
	
		if($('#otherchildname').val() != '') {
	
			previousMarriageChildren.push($('#otherchildname').val().trim());
			//console.log(currentMarriageChildren);
				
			var htmlString = "";
			
			for (var i = 0; i < previousMarriageChildren.length; i++) {
				htmlString += "<tr><td>";
				htmlString += previousMarriageChildren[i];
				htmlString += '<span style="float:right;cursor:pointer" onclick="removePreviousChild(' + i + ')">✕</span></td></tr>';
			}
			
			$('#childrenfromprevioustable tbody').html(htmlString);
			
			$('#otherchildname').val('');
			
		}
	
	}
	
	
	// AJAX

	$.get('getStates.php', function(data){
	
		$('#state').html(data);
		
	});
	
	$('#state').on('change', function() {
	
		state = $('#state option:selected').text();
	
  		/*$.ajax({
				
			type: "GET",
			url: "getCounties.php",
			data: {	stateId: $('#state').val()}
			
		}).done(function(data){
		
			$('#county').html(data);

		});*/
  		
	});
	
	function generate() {
	
		var doc = new jsPDF('p', 'in', [8.5,11]);
		doc.setFont("Times New Roman", "bold");
		doc.setFontSize(12);
		doc.setLineWidth(6.5);
		
		
		doc.myText("LAST WILL AND TESTAMENT", {align: "center"}, 0, 1);
		doc.myText("OF", {align: "center"}, 1, 1.2);
		doc.myText(legalName.toUpperCase(), {align: "center"}, 1, 1.4);
		
		doc.setFontStyle("regular");
		
		var toBeSplit = "I, " + legalName + ", presently of " + state + ", declare this to be my Last Will and Testament, revoking all prior wills and condicils made by me.";
		var split = doc.splitTextToSize(toBeSplit, 6.5);
		doc.text(split, 1, 2);
		var offset1 = doc.getTextDimensions(split).h / 100;
		
		doc.setFontStyle("bold");
		var part1 = "1. Preliminary Statements";
		doc.text(part1, 1, 2.4 + offset1);
		
		doc.setFontStyle("regular");
		var secondParagraph = "";
		
		if(isMarried) {
			secondParagraph += "I am married to " + spouseLegalName;
		} else {
			secondParagraph += "I am not married. ";
		}
		
		if(hasChildrenFromCurrentMarriage && isMarried) {
			if (currentMarriageChildren.length == 1) secondParagraph += ", and we have one child. ";
			else secondParagraph += ", and we have " + currentMarriageChildren.length + " children. ";
			if(currentMarriageChildren.length > 2) {
			
				secondParagraph += "Our children are named ";
				for(var i = 0; i < currentMarriageChildren.length - 1; i++) {
					secondParagraph += currentMarriageChildren[i] + ", ";
				}
				secondParagraph += "and " + currentMarriageChildren[currentMarriageChildren.length - 1] + ".";
				
			} else if (currentMarriageChildren.length == 2) {
				secondParagraph += "Our children are named " + currentMarriageChildren[0] + " and " + currentMarriageChildren[1] + ". ";
			} else {
				secondParagraph += "Our only child is named " + currentMarriageChildren[0] + ". ";
			}
		} else if (!hasChildrenFromCurrentMarriage && isMarried) {
			secondParagraph += ".";
		}
		
		if(hasChildrenFromPreviousMarriage) {
			if (previousMarriageChildren.length == 1) secondParagraph += "I have one child not from my current marriage, named ";
			else secondParagraph += "I have " + previousMarriageChildren.length + " children not from my current marriage, and they are named ";
			if(previousMarriageChildren.length > 2) {
			
				for(var i = 0; i < previousMarriageChildren.length - 1; i++) {
					secondParagraph += previousMarriageChildren[i] + ", ";
				}
				secondParagraph += "and " + previousMarriageChildren[previousMarriageChildren.length - 1] + ". ";
				
			} else if (previousMarriageChildren.length == 2) {
				secondParagraph += previousMarriageChildren[0] + " and " + previousMarriageChildren[1] + ". ";
			} else {
				secondParagraph += previousMarriageChildren[0] + ".";
			}
		} 
		
		split = doc.splitTextToSize(secondParagraph, 6.5);
		doc.text(split, 1, 2.6 + offset1);
		
		
		// save/open in new window
		//doc.save("Last Will and Testament of " + $('#name').val());
		doc.output('dataurlnewwindow');
	
	}
	
	$('.propername').on("keyup", function() {
	
		var currentPos = $(this).getCursorPosition();
		
		for (i = 0; i < $(this).val().length; i++) { 
    			if (i == 0) {
    				$(this).val($(this).val().charAt(0).toUpperCase() + $(this).val().substr(1));
    			} else if ($(this).val().charAt(i-1) == " ") {
    				$(this).val($(this).val().substr(0, i) + $(this).val().charAt(i).toUpperCase() + $(this).val().substr(i+1));
    				setSelectionRange(this, currentPos, currentPos);
    			}
		}
	
	});
	
	
	
	(function(API){
	    API.myText = function(txt, options, x, y) {
	        options = options ||{};
	        if( options.align == "center" ) {
	            var fontSize = this.internal.getFontSize();
	            var pageWidth = this.internal.pageSize.width;
	            txtWidth = this.getStringUnitWidth(txt)*fontSize/this.internal.scaleFactor;
	            x = ( pageWidth - txtWidth ) / 2;
	        }
	
	        this.text(txt,x,y);
	
	    }
	})(jsPDF.API);
	
	(function($) {
	    $.fn.getCursorPosition = function() {
	        var input = this.get(0);
	        if (!input) return; // No (input) element found
	        if ('selectionStart' in input) {
	            // Standard-compliant browsers
	            return input.selectionStart;
	        } else if (document.selection) {
	            // IE
	            input.focus();
	            var sel = document.selection.createRange();
	            var selLen = document.selection.createRange().text.length;
	            sel.moveStart('character', -input.value.length);
	            return sel.text.length - selLen;
	        }
	    }
	})(jQuery);
	
	function setSelectionRange(input, selectionStart, selectionEnd) {
	  if (input.setSelectionRange) {
	    input.focus();
	    input.setSelectionRange(selectionStart, selectionEnd);
	  }
	  else if (input.createTextRange) {
	    var range = input.createTextRange();
	    range.collapse(true);
	    range.moveEnd('character', selectionEnd);
	    range.moveStart('character', selectionStart);
	    range.select();
	  }
	}
        
});

function removeCurrentChild(index) {
	//console.log(index);
	currentMarriageChildren.splice(index, 1);
	//console.log(currentMarriageChildren);
	
	var htmlString = "";
			
	for (var i = 0; i < currentMarriageChildren.length; i++) {
		htmlString += "<tr><td>";
		htmlString += currentMarriageChildren[i];
		htmlString += '<span style="float:right;cursor:pointer" onclick="removeCurrentChild(' + i + ')">✕</span></td></tr>';
	}
	
	if(htmlString == "") htmlString = "<tr><td>No children entered yet.</td></tr>";
	
	$('#childrenfromcurrenttable tbody').html(htmlString);
	
}

function removePreviousChild(index) {
	//console.log(index);
	previousMarriageChildren.splice(index, 1);
	//console.log(currentMarriageChildren);
	
	var htmlString = "";
			
	for (var i = 0; i < previousMarriageChildren.length; i++) {
		htmlString += "<tr><td>";
		htmlString += previousMarriageChildren[i];
		htmlString += '<span style="float:right;cursor:pointer" onclick="removePreviousChild(' + i + ')">✕</span></td></tr>';
	}
	
	if(htmlString == "") htmlString = "<tr><td>No children entered yet.</td></tr>";
	
	$('#childrenfromprevioustable tbody').html(htmlString);
	
}

if (document.getElementsByTagName) {

	var inputElements = document.getElementsByTagName('input');

	for (i=0; inputElements[i]; i++) {
	
		if (inputElements[i].className && (inputElements[i].className.indexOf('disableAutoComplete') != -1)) {
	
			inputElements[i].setAttribute('autocomplete','off');
	
		}

	}

}

</script>
</body>
</html>