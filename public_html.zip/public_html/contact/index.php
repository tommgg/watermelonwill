<!DOCTYPE html>
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "/style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="jspdf.min.js"></script>
<meta name="viewport" content="width=device-width">
<meta name="viewport" content="initial-scale=1.0">
<title>Watermelon Will</title>
</head>
<body>
<div id="titlebar">
  <h2>Watermelon Will</h2>
  <ul id="sitemenu">
    <li><a href="/home">HOME</a></li>
    <li><a href="/">CREATE</a></li>
    <li><a href="/blog">BLOG</a></li>
    <li><a href="/faqs">FAQs</a></li>
    <li><a href="/contact" id="selectedmenuitem">CONTACT</a></li>
  </ul>
</div>
</body>
</html>